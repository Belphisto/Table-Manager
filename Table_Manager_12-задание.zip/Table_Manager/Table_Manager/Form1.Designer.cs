﻿namespace Table_Manager
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            toolStripStatusLabel2 = new ToolStripStatusLabel();
            dataGridView1 = new DataGridView();
            menuStrip1 = new MenuStrip();
            файлToolStripMenuItem = new ToolStripMenuItem();
            создатьToolStripMenuItem1 = new ToolStripMenuItem();
            открытьToolStripMenuItem1 = new ToolStripMenuItem();
            toolStripSeparator6 = new ToolStripSeparator();
            сохранитьToolStripMenuItem1 = new ToolStripMenuItem();
            сохранитькакToolStripMenuItem1 = new ToolStripMenuItem();
            toolStripSeparator7 = new ToolStripSeparator();
            toolStripSeparator8 = new ToolStripSeparator();
            импортToolStripMenuItem = new ToolStripMenuItem();
            wordToolStripMenuItem = new ToolStripMenuItem();
            exelToolStripMenuItem = new ToolStripMenuItem();
            notePadToolStripMenuItem = new ToolStripMenuItem();
            изменитьToolStripMenuItem = new ToolStripMenuItem();
            отменитьToolStripMenuItem1 = new ToolStripMenuItem();
            toolStripSeparator9 = new ToolStripSeparator();
            AddToolStripMenuItem = new ToolStripMenuItem();
            EditToolStripMenuItem = new ToolStripMenuItem();
            DeleteToolStripMenuItem1 = new ToolStripMenuItem();
            toolStripSeparator10 = new ToolStripSeparator();
            выбратьвсеToolStripMenuItem1 = new ToolStripMenuItem();
            инструментыToolStripMenuItem = new ToolStripMenuItem();
            настройкиToolStripMenuItem1 = new ToolStripMenuItem();
            параметрыToolStripMenuItem1 = new ToolStripMenuItem();
            операцииСДаннымиToolStripMenuItem = new ToolStripMenuItem();
            справкаToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator5 = new ToolStripSeparator();
            AboutProgramToolStripMenuItem = new ToolStripMenuItem();
            выходToolStripMenuItem2 = new ToolStripMenuItem();
            настройкиToolStripMenuItem = new ToolStripMenuItem();
            параметрыToolStripMenuItem = new ToolStripMenuItem();
            отменитьToolStripMenuItem = new ToolStripMenuItem();
            повторитьToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator3 = new ToolStripSeparator();
            вырезатьToolStripMenuItem = new ToolStripMenuItem();
            копироватьToolStripMenuItem = new ToolStripMenuItem();
            вставитьToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator4 = new ToolStripSeparator();
            выбратьвсеToolStripMenuItem = new ToolStripMenuItem();
            создатьToolStripMenuItem = new ToolStripMenuItem();
            открытьToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator = new ToolStripSeparator();
            сохранитьToolStripMenuItem = new ToolStripMenuItem();
            сохранитькакToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            печатьToolStripMenuItem = new ToolStripMenuItem();
            предварительныйпросмотрToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator2 = new ToolStripSeparator();
            выходToolStripMenuItem = new ToolStripMenuItem();
            CurrentRowTextBox = new TextBox();
            toolStripMenuItem1 = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripMenuItem();
            toolStripMenuItem3 = new ToolStripMenuItem();
            toolStripSeparator11 = new ToolStripSeparator();
            опрограммеToolStripMenuItem = new ToolStripMenuItem();
            toolStrip1 = new ToolStrip();
            toolStripSeparator12 = new ToolStripSeparator();
            DeleteToolStripButton = new ToolStripButton();
            EditToolStripButton = new ToolStripButton();
            AddToolStripButton = new ToolStripButton();
            toolStripSeparator13 = new ToolStripSeparator();
            CreateToolStripButton = new ToolStripButton();
            OpenToolStripButton = new ToolStripButton();
            SaveToolStripButton = new ToolStripButton();
            toolStripSeparator14 = new ToolStripSeparator();
            toolStripSeparator15 = new ToolStripSeparator();
            openFileDialog1 = new OpenFileDialog();
            saveFileDialog1 = new SaveFileDialog();
            statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            menuStrip1.SuspendLayout();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // statusStrip1
            // 
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1, toolStripStatusLabel2 });
            statusStrip1.Location = new Point(0, 492);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.RenderMode = ToolStripRenderMode.ManagerRenderMode;
            statusStrip1.Size = new Size(800, 22);
            statusStrip1.TabIndex = 0;
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(167, 17);
            toolStripStatusLabel1.Text = "Приложение Windows Forms";
            // 
            // toolStripStatusLabel2
            // 
            toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            toolStripStatusLabel2.Size = new Size(317, 17);
            toolStripStatusLabel2.Text = "Целевая платформа: .Net 6.0 (долгосрочная поддержка)";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 52);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(791, 408);
            dataGridView1.TabIndex = 1;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { файлToolStripMenuItem, изменитьToolStripMenuItem, инструментыToolStripMenuItem, операцииСДаннымиToolStripMenuItem, справкаToolStripMenuItem, выходToolStripMenuItem2 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 2;
            menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            файлToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { создатьToolStripMenuItem1, открытьToolStripMenuItem1, toolStripSeparator6, сохранитьToolStripMenuItem1, сохранитькакToolStripMenuItem1, toolStripSeparator7, toolStripSeparator8, импортToolStripMenuItem });
            файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            файлToolStripMenuItem.Size = new Size(48, 20);
            файлToolStripMenuItem.Text = "&Файл";
            // 
            // создатьToolStripMenuItem1
            // 
            создатьToolStripMenuItem1.Image = (Image)resources.GetObject("создатьToolStripMenuItem1.Image");
            создатьToolStripMenuItem1.ImageTransparentColor = Color.Magenta;
            создатьToolStripMenuItem1.Name = "создатьToolStripMenuItem1";
            создатьToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.C;
            создатьToolStripMenuItem1.Size = new Size(195, 22);
            создатьToolStripMenuItem1.Text = "&Создать";
            создатьToolStripMenuItem1.Click += CreateToolStripMenuItem1_Click;
            // 
            // открытьToolStripMenuItem1
            // 
            открытьToolStripMenuItem1.Image = (Image)resources.GetObject("открытьToolStripMenuItem1.Image");
            открытьToolStripMenuItem1.ImageTransparentColor = Color.Magenta;
            открытьToolStripMenuItem1.Name = "открытьToolStripMenuItem1";
            открытьToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.O;
            открытьToolStripMenuItem1.Size = new Size(195, 22);
            открытьToolStripMenuItem1.Text = "&Открыть";
            открытьToolStripMenuItem1.Click += OpenToolStripMenuItem1_Click;
            // 
            // toolStripSeparator6
            // 
            toolStripSeparator6.Name = "toolStripSeparator6";
            toolStripSeparator6.Size = new Size(192, 6);
            // 
            // сохранитьToolStripMenuItem1
            // 
            сохранитьToolStripMenuItem1.Image = (Image)resources.GetObject("сохранитьToolStripMenuItem1.Image");
            сохранитьToolStripMenuItem1.ImageTransparentColor = Color.Magenta;
            сохранитьToolStripMenuItem1.Name = "сохранитьToolStripMenuItem1";
            сохранитьToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.S;
            сохранитьToolStripMenuItem1.Size = new Size(195, 22);
            сохранитьToolStripMenuItem1.Text = "&Сохранить";
            сохранитьToolStripMenuItem1.Click += SaveToolStripMenuItem1_Click;
            // 
            // сохранитькакToolStripMenuItem1
            // 
            сохранитькакToolStripMenuItem1.Name = "сохранитькакToolStripMenuItem1";
            сохранитькакToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.K;
            сохранитькакToolStripMenuItem1.Size = new Size(195, 22);
            сохранитькакToolStripMenuItem1.Text = "Сохранить &как";
            сохранитькакToolStripMenuItem1.Click += SaveAsToolStripMenuItem1_Click;
            // 
            // toolStripSeparator7
            // 
            toolStripSeparator7.Name = "toolStripSeparator7";
            toolStripSeparator7.Size = new Size(192, 6);
            // 
            // toolStripSeparator8
            // 
            toolStripSeparator8.Name = "toolStripSeparator8";
            toolStripSeparator8.Size = new Size(192, 6);
            // 
            // импортToolStripMenuItem
            // 
            импортToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { wordToolStripMenuItem, exelToolStripMenuItem, notePadToolStripMenuItem });
            импортToolStripMenuItem.Name = "импортToolStripMenuItem";
            импортToolStripMenuItem.Size = new Size(195, 22);
            импортToolStripMenuItem.Text = "Импорт";
            // 
            // wordToolStripMenuItem
            // 
            wordToolStripMenuItem.Name = "wordToolStripMenuItem";
            wordToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.W;
            wordToolStripMenuItem.Size = new Size(163, 22);
            wordToolStripMenuItem.Text = "Word";
            wordToolStripMenuItem.Click += wordToolStripMenuItem_Click;
            // 
            // exelToolStripMenuItem
            // 
            exelToolStripMenuItem.Name = "exelToolStripMenuItem";
            exelToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.E;
            exelToolStripMenuItem.Size = new Size(163, 22);
            exelToolStripMenuItem.Text = "Exel";
            exelToolStripMenuItem.Click += exelToolStripMenuItem_Click;
            // 
            // notePadToolStripMenuItem
            // 
            notePadToolStripMenuItem.Name = "notePadToolStripMenuItem";
            notePadToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.N;
            notePadToolStripMenuItem.Size = new Size(163, 22);
            notePadToolStripMenuItem.Text = "NotePad";
            // 
            // изменитьToolStripMenuItem
            // 
            изменитьToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { отменитьToolStripMenuItem1, toolStripSeparator9, AddToolStripMenuItem, EditToolStripMenuItem, DeleteToolStripMenuItem1, toolStripSeparator10, выбратьвсеToolStripMenuItem1 });
            изменитьToolStripMenuItem.Name = "изменитьToolStripMenuItem";
            изменитьToolStripMenuItem.Size = new Size(59, 20);
            изменитьToolStripMenuItem.Text = "&Правка";
            // 
            // отменитьToolStripMenuItem1
            // 
            отменитьToolStripMenuItem1.Name = "отменитьToolStripMenuItem1";
            отменитьToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.Z;
            отменитьToolStripMenuItem1.Size = new Size(169, 22);
            отменитьToolStripMenuItem1.Text = "&Отменить";
            // 
            // toolStripSeparator9
            // 
            toolStripSeparator9.Name = "toolStripSeparator9";
            toolStripSeparator9.Size = new Size(166, 6);
            // 
            // AddToolStripMenuItem
            // 
            AddToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            AddToolStripMenuItem.Name = "AddToolStripMenuItem";
            AddToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.A;
            AddToolStripMenuItem.Size = new Size(169, 22);
            AddToolStripMenuItem.Text = "&Добавить";
            AddToolStripMenuItem.Click += AddToolStripMenuItem_Click;
            // 
            // EditToolStripMenuItem
            // 
            EditToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            EditToolStripMenuItem.Name = "EditToolStripMenuItem";
            EditToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.E;
            EditToolStripMenuItem.Size = new Size(169, 22);
            EditToolStripMenuItem.Text = "&Изменить";
            EditToolStripMenuItem.Click += EditToolStripMenuItem_Click;
            // 
            // DeleteToolStripMenuItem1
            // 
            DeleteToolStripMenuItem1.ImageTransparentColor = Color.Magenta;
            DeleteToolStripMenuItem1.Name = "DeleteToolStripMenuItem1";
            DeleteToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.D;
            DeleteToolStripMenuItem1.Size = new Size(169, 22);
            DeleteToolStripMenuItem1.Text = "&Удалить";
            DeleteToolStripMenuItem1.Click += DeleteToolStripMenuItem1_Click;
            // 
            // toolStripSeparator10
            // 
            toolStripSeparator10.Name = "toolStripSeparator10";
            toolStripSeparator10.Size = new Size(166, 6);
            // 
            // выбратьвсеToolStripMenuItem1
            // 
            выбратьвсеToolStripMenuItem1.Name = "выбратьвсеToolStripMenuItem1";
            выбратьвсеToolStripMenuItem1.Size = new Size(169, 22);
            выбратьвсеToolStripMenuItem1.Text = "Выбрать &все";
            // 
            // инструментыToolStripMenuItem
            // 
            инструментыToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { настройкиToolStripMenuItem1, параметрыToolStripMenuItem1 });
            инструментыToolStripMenuItem.Name = "инструментыToolStripMenuItem";
            инструментыToolStripMenuItem.Size = new Size(95, 20);
            инструментыToolStripMenuItem.Text = "&Инструменты";
            // 
            // настройкиToolStripMenuItem1
            // 
            настройкиToolStripMenuItem1.Name = "настройкиToolStripMenuItem1";
            настройкиToolStripMenuItem1.Size = new Size(138, 22);
            настройкиToolStripMenuItem1.Text = "&Настройки";
            // 
            // параметрыToolStripMenuItem1
            // 
            параметрыToolStripMenuItem1.Name = "параметрыToolStripMenuItem1";
            параметрыToolStripMenuItem1.Size = new Size(138, 22);
            параметрыToolStripMenuItem1.Text = "&Параметры";
            // 
            // операцииСДаннымиToolStripMenuItem
            // 
            операцииСДаннымиToolStripMenuItem.Name = "операцииСДаннымиToolStripMenuItem";
            операцииСДаннымиToolStripMenuItem.Size = new Size(138, 20);
            операцииСДаннымиToolStripMenuItem.Text = "&Операции с данными";
            // 
            // справкаToolStripMenuItem
            // 
            справкаToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { toolStripSeparator5, AboutProgramToolStripMenuItem });
            справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            справкаToolStripMenuItem.Size = new Size(65, 20);
            справкаToolStripMenuItem.Text = "&Справка";
            // 
            // toolStripSeparator5
            // 
            toolStripSeparator5.Name = "toolStripSeparator5";
            toolStripSeparator5.Size = new Size(155, 6);
            // 
            // AboutProgramToolStripMenuItem
            // 
            AboutProgramToolStripMenuItem.Name = "AboutProgramToolStripMenuItem";
            AboutProgramToolStripMenuItem.Size = new Size(158, 22);
            AboutProgramToolStripMenuItem.Text = "&О программе…";
            AboutProgramToolStripMenuItem.Click += AboutProgramToolStripMenuItem_Click;
            // 
            // выходToolStripMenuItem2
            // 
            выходToolStripMenuItem2.Name = "выходToolStripMenuItem2";
            выходToolStripMenuItem2.Size = new Size(54, 20);
            выходToolStripMenuItem2.Text = "Выход";
            // 
            // настройкиToolStripMenuItem
            // 
            настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            настройкиToolStripMenuItem.Size = new Size(32, 19);
            настройкиToolStripMenuItem.Text = "&Настройки";
            // 
            // параметрыToolStripMenuItem
            // 
            параметрыToolStripMenuItem.Name = "параметрыToolStripMenuItem";
            параметрыToolStripMenuItem.Size = new Size(32, 19);
            параметрыToolStripMenuItem.Text = "&Параметры";
            // 
            // отменитьToolStripMenuItem
            // 
            отменитьToolStripMenuItem.Name = "отменитьToolStripMenuItem";
            отменитьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Z;
            отменитьToolStripMenuItem.Size = new Size(32, 19);
            отменитьToolStripMenuItem.Text = "&Отменить";
            // 
            // повторитьToolStripMenuItem
            // 
            повторитьToolStripMenuItem.Name = "повторитьToolStripMenuItem";
            повторитьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Y;
            повторитьToolStripMenuItem.Size = new Size(32, 19);
            повторитьToolStripMenuItem.Text = "&Повторить";
            // 
            // toolStripSeparator3
            // 
            toolStripSeparator3.Name = "toolStripSeparator3";
            toolStripSeparator3.Size = new Size(6, 6);
            // 
            // вырезатьToolStripMenuItem
            // 
            вырезатьToolStripMenuItem.Image = (Image)resources.GetObject("вырезатьToolStripMenuItem.Image");
            вырезатьToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            вырезатьToolStripMenuItem.Name = "вырезатьToolStripMenuItem";
            вырезатьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.X;
            вырезатьToolStripMenuItem.Size = new Size(32, 19);
            вырезатьToolStripMenuItem.Text = "В&ырезать";
            // 
            // копироватьToolStripMenuItem
            // 
            копироватьToolStripMenuItem.Image = (Image)resources.GetObject("копироватьToolStripMenuItem.Image");
            копироватьToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            копироватьToolStripMenuItem.Name = "копироватьToolStripMenuItem";
            копироватьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.C;
            копироватьToolStripMenuItem.Size = new Size(32, 19);
            копироватьToolStripMenuItem.Text = "&Копировать";
            // 
            // вставитьToolStripMenuItem
            // 
            вставитьToolStripMenuItem.Image = (Image)resources.GetObject("вставитьToolStripMenuItem.Image");
            вставитьToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            вставитьToolStripMenuItem.Name = "вставитьToolStripMenuItem";
            вставитьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.V;
            вставитьToolStripMenuItem.Size = new Size(32, 19);
            вставитьToolStripMenuItem.Text = "&Вставить";
            // 
            // toolStripSeparator4
            // 
            toolStripSeparator4.Name = "toolStripSeparator4";
            toolStripSeparator4.Size = new Size(6, 6);
            // 
            // выбратьвсеToolStripMenuItem
            // 
            выбратьвсеToolStripMenuItem.Name = "выбратьвсеToolStripMenuItem";
            выбратьвсеToolStripMenuItem.Size = new Size(32, 19);
            выбратьвсеToolStripMenuItem.Text = "Выбрать &все";
            // 
            // создатьToolStripMenuItem
            // 
            создатьToolStripMenuItem.Image = (Image)resources.GetObject("создатьToolStripMenuItem.Image");
            создатьToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            создатьToolStripMenuItem.Name = "создатьToolStripMenuItem";
            создатьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.N;
            создатьToolStripMenuItem.Size = new Size(32, 19);
            создатьToolStripMenuItem.Text = "&Создать";
            // 
            // открытьToolStripMenuItem
            // 
            открытьToolStripMenuItem.Image = (Image)resources.GetObject("открытьToolStripMenuItem.Image");
            открытьToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            открытьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.O;
            открытьToolStripMenuItem.Size = new Size(32, 19);
            открытьToolStripMenuItem.Text = "&Открыть";
            // 
            // toolStripSeparator
            // 
            toolStripSeparator.Name = "toolStripSeparator";
            toolStripSeparator.Size = new Size(6, 6);
            // 
            // сохранитьToolStripMenuItem
            // 
            сохранитьToolStripMenuItem.Image = (Image)resources.GetObject("сохранитьToolStripMenuItem.Image");
            сохранитьToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            сохранитьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.S;
            сохранитьToolStripMenuItem.Size = new Size(32, 19);
            сохранитьToolStripMenuItem.Text = "&Сохранить";
            // 
            // сохранитькакToolStripMenuItem
            // 
            сохранитькакToolStripMenuItem.Name = "сохранитькакToolStripMenuItem";
            сохранитькакToolStripMenuItem.Size = new Size(32, 19);
            сохранитькакToolStripMenuItem.Text = "Сохранить &как";
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(6, 6);
            // 
            // печатьToolStripMenuItem
            // 
            печатьToolStripMenuItem.Image = (Image)resources.GetObject("печатьToolStripMenuItem.Image");
            печатьToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            печатьToolStripMenuItem.Name = "печатьToolStripMenuItem";
            печатьToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.P;
            печатьToolStripMenuItem.Size = new Size(32, 19);
            печатьToolStripMenuItem.Text = "&Печать";
            // 
            // предварительныйпросмотрToolStripMenuItem
            // 
            предварительныйпросмотрToolStripMenuItem.Image = (Image)resources.GetObject("предварительныйпросмотрToolStripMenuItem.Image");
            предварительныйпросмотрToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            предварительныйпросмотрToolStripMenuItem.Name = "предварительныйпросмотрToolStripMenuItem";
            предварительныйпросмотрToolStripMenuItem.Size = new Size(32, 19);
            предварительныйпросмотрToolStripMenuItem.Text = "Предварительный про&смотр";
            // 
            // toolStripSeparator2
            // 
            toolStripSeparator2.Name = "toolStripSeparator2";
            toolStripSeparator2.Size = new Size(6, 6);
            // 
            // выходToolStripMenuItem
            // 
            выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            выходToolStripMenuItem.Size = new Size(32, 19);
            выходToolStripMenuItem.Text = "Вы&ход";
            // 
            // CurrentRowTextBox
            // 
            CurrentRowTextBox.Location = new Point(0, 466);
            CurrentRowTextBox.Name = "CurrentRowTextBox";
            CurrentRowTextBox.Size = new Size(791, 23);
            CurrentRowTextBox.TabIndex = 3;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(32, 19);
            toolStripMenuItem1.Text = "&Содержимое";
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(32, 19);
            toolStripMenuItem2.Text = "&Индекс";
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new Size(32, 19);
            toolStripMenuItem3.Text = "&Поиск";
            // 
            // toolStripSeparator11
            // 
            toolStripSeparator11.Name = "toolStripSeparator11";
            toolStripSeparator11.Size = new Size(6, 6);
            // 
            // опрограммеToolStripMenuItem
            // 
            опрограммеToolStripMenuItem.Name = "опрограммеToolStripMenuItem";
            опрограммеToolStripMenuItem.Size = new Size(32, 19);
            опрограммеToolStripMenuItem.Text = "&О программе…";
            // 
            // toolStrip1
            // 
            toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripSeparator12, DeleteToolStripButton, EditToolStripButton, AddToolStripButton, toolStripSeparator13, CreateToolStripButton, OpenToolStripButton, SaveToolStripButton, toolStripSeparator14, toolStripSeparator15 });
            toolStrip1.Location = new Point(0, 24);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(800, 25);
            toolStrip1.TabIndex = 4;
            toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator12
            // 
            toolStripSeparator12.Name = "toolStripSeparator12";
            toolStripSeparator12.Size = new Size(6, 25);
            // 
            // DeleteToolStripButton
            // 
            DeleteToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Image;
            DeleteToolStripButton.Image = (Image)resources.GetObject("DeleteToolStripButton.Image");
            DeleteToolStripButton.ImageTransparentColor = Color.Magenta;
            DeleteToolStripButton.Name = "DeleteToolStripButton";
            DeleteToolStripButton.Size = new Size(23, 22);
            DeleteToolStripButton.Text = "Вы&резать";
            DeleteToolStripButton.ToolTipText = "Удалить";
            // 
            // EditToolStripButton
            // 
            EditToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Image;
            EditToolStripButton.Image = (Image)resources.GetObject("EditToolStripButton.Image");
            EditToolStripButton.ImageTransparentColor = Color.Magenta;
            EditToolStripButton.Name = "EditToolStripButton";
            EditToolStripButton.Size = new Size(23, 22);
            EditToolStripButton.Text = "&Копировать";
            EditToolStripButton.ToolTipText = "Редактировать";
            // 
            // AddToolStripButton
            // 
            AddToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Image;
            AddToolStripButton.Image = (Image)resources.GetObject("AddToolStripButton.Image");
            AddToolStripButton.ImageTransparentColor = Color.Magenta;
            AddToolStripButton.Name = "AddToolStripButton";
            AddToolStripButton.Size = new Size(23, 22);
            AddToolStripButton.Text = "&Вставить";
            AddToolStripButton.ToolTipText = "Создать";
            // 
            // toolStripSeparator13
            // 
            toolStripSeparator13.Name = "toolStripSeparator13";
            toolStripSeparator13.Size = new Size(6, 25);
            // 
            // CreateToolStripButton
            // 
            CreateToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CreateToolStripButton.Image = (Image)resources.GetObject("CreateToolStripButton.Image");
            CreateToolStripButton.ImageTransparentColor = Color.Magenta;
            CreateToolStripButton.Name = "CreateToolStripButton";
            CreateToolStripButton.Size = new Size(23, 22);
            CreateToolStripButton.Text = "&Создать";
            // 
            // OpenToolStripButton
            // 
            OpenToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Image;
            OpenToolStripButton.Image = (Image)resources.GetObject("OpenToolStripButton.Image");
            OpenToolStripButton.ImageTransparentColor = Color.Magenta;
            OpenToolStripButton.Name = "OpenToolStripButton";
            OpenToolStripButton.Size = new Size(23, 22);
            OpenToolStripButton.Text = "&Открыть";
            // 
            // SaveToolStripButton
            // 
            SaveToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Image;
            SaveToolStripButton.Image = (Image)resources.GetObject("SaveToolStripButton.Image");
            SaveToolStripButton.ImageTransparentColor = Color.Magenta;
            SaveToolStripButton.Name = "SaveToolStripButton";
            SaveToolStripButton.Size = new Size(23, 22);
            SaveToolStripButton.Text = "&Сохранить";
            // 
            // toolStripSeparator14
            // 
            toolStripSeparator14.Name = "toolStripSeparator14";
            toolStripSeparator14.Size = new Size(6, 25);
            // 
            // toolStripSeparator15
            // 
            toolStripSeparator15.Name = "toolStripSeparator15";
            toolStripSeparator15.Size = new Size(6, 25);
            // 
            // openFileDialog1
            // 
            openFileDialog1.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            // 
            // saveFileDialog1
            // 
            saveFileDialog1.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 514);
            Controls.Add(toolStrip1);
            Controls.Add(CurrentRowTextBox);
            Controls.Add(dataGridView1);
            Controls.Add(statusStrip1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Табличный менеджер \"Гарри Поттер и все все все\"";
            Load += Form1_Load;
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel2;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem справкаToolStripMenuItem;
        private ToolStripMenuItem содержимоеToolStripMenuItem;
        private ToolStripMenuItem индексToolStripMenuItem;
        private ToolStripMenuItem поискToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripMenuItem AboutProgramToolStripMenuItem;
        private ToolStripMenuItem настройкиToolStripMenuItem;
        private ToolStripMenuItem параметрыToolStripMenuItem;
        private ToolStripMenuItem отменитьToolStripMenuItem;
        private ToolStripMenuItem повторитьToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripMenuItem вырезатьToolStripMenuItem;
        private ToolStripMenuItem копироватьToolStripMenuItem;
        private ToolStripMenuItem вставитьToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripMenuItem выбратьвсеToolStripMenuItem;
        private ToolStripMenuItem создатьToolStripMenuItem;
        private ToolStripMenuItem открытьToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator;
        private ToolStripMenuItem сохранитьToolStripMenuItem;
        private ToolStripMenuItem сохранитькакToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem печатьToolStripMenuItem;
        private ToolStripMenuItem предварительныйпросмотрToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem выходToolStripMenuItem;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private TextBox CurrentRowTextBox;
        private ToolStripMenuItem файлToolStripMenuItem;
        private ToolStripMenuItem создатьToolStripMenuItem1;
        private ToolStripMenuItem открытьToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator6;
        private ToolStripMenuItem сохранитьToolStripMenuItem1;
        private ToolStripMenuItem сохранитькакToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator7;
        private ToolStripSeparator toolStripSeparator8;
        private ToolStripMenuItem изменитьToolStripMenuItem;
        private ToolStripMenuItem отменитьToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator9;
        private ToolStripMenuItem AddToolStripMenuItem;
        private ToolStripMenuItem EditToolStripMenuItem;
        private ToolStripMenuItem DeleteToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator10;
        private ToolStripMenuItem выбратьвсеToolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripSeparator toolStripSeparator11;
        private ToolStripMenuItem опрограммеToolStripMenuItem;
        private ToolStripMenuItem операцииСДаннымиToolStripMenuItem;
        private ToolStripMenuItem выходToolStripMenuItem2;
        private ToolStrip toolStrip1;
        private ToolStripSeparator toolStripSeparator12;
        private ToolStripButton DeleteToolStripButton;
        private ToolStripButton EditToolStripButton;
        private ToolStripButton AddToolStripButton;
        private ToolStripSeparator toolStripSeparator13;
        private ToolStripMenuItem импортToolStripMenuItem;
        private ToolStripMenuItem wordToolStripMenuItem;
        private ToolStripMenuItem exelToolStripMenuItem;
        private ToolStripMenuItem notePadToolStripMenuItem;
        private ToolStripMenuItem инструментыToolStripMenuItem;
        private ToolStripMenuItem настройкиToolStripMenuItem1;
        private ToolStripMenuItem параметрыToolStripMenuItem1;
        private OpenFileDialog openFileDialog1;
        private ToolStripButton CreateToolStripButton;
        private ToolStripButton OpenToolStripButton;
        private ToolStripButton SaveToolStripButton;
        private ToolStripSeparator toolStripSeparator14;
        private ToolStripSeparator toolStripSeparator15;
        private SaveFileDialog saveFileDialog1;
    }
}